@echo off
title Cai dat Trinh dieu khien May in HIS Online

echo ======================================================
echo   DANG TU DONG CAU HINH TRINH DIEU KHIEN IN (QZ TRAY)
echo ======================================================
echo.

:: Check Admin rights
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [ERROR] Vui long chuot phai chon "Run as Administrator"
    echo [ERROR] Please run this file as Administrator.
    pause
    exit /b
)

:: Get default QZ Tray installation path
set "QZ_DIR=C:\Program Files\QZ Tray"
if not exist "%QZ_DIR%" (
    set "QZ_DIR=C:\Program Files (x86)\QZ Tray"
)

:: 1. Install QZ Tray offline if not already installed
if not exist "%QZ_DIR%\qz-tray.jar" (
    echo [1/2] Installing QZ Tray service...
    if exist "%~dp0qz-tray-2.2.6-x86_64.exe" (
        start /wait "" "%~dp0qz-tray-2.2.6-x86_64.exe" /S
    ) else (
        echo [ERROR] File qz-tray-2.2.6-x86_64.exe not found!
        pause
        exit /b
    )
) else (
    echo [*] QZ Tray is already installed.
)

:: Update path after installation
set "QZ_DIR=C:\Program Files\QZ Tray"
if not exist "%QZ_DIR%" (
    set "QZ_DIR=C:\Program Files (x86)\QZ Tray"
)

:: 2. Copy override.crt certificate
echo [2/2] Loading clinic digital certificate...
if exist "%QZ_DIR%" (
    copy /Y "%~dp0override.crt" "%QZ_DIR%\override.crt" > nul
    echo [OK] Loaded digital certificate successfully!
) else (
    echo [ERROR] QZ Tray directory not found!
    pause
    exit /b
)

:: 3. Start QZ Tray
echo.
echo [*] Starting QZ Tray service...
if exist "%QZ_DIR%\qz-tray.exe" (
    start "" "%QZ_DIR%\qz-tray.exe"
)

echo.
echo ======================================================
echo   SUCCESS! CAI DAT THANH CONG. BAN CO THE IN NGAY.
echo ======================================================
echo.
pause
